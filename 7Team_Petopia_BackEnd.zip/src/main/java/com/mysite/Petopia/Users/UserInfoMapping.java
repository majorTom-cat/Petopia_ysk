package com.mysite.Petopia.Users;


public interface UserInfoMapping {

	
	
}
