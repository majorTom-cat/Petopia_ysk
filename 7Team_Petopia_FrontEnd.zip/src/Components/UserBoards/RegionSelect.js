import React from "react";

const RegionSelect = (props) => {
  return <article>{props.children}</article>;
};

export default RegionSelect;
